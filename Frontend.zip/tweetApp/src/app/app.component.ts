import { Component, OnChanges, SimpleChanges } from '@angular/core';
import { MainService } from './main.service';
import {Router } from '@angular/router';
import { FormGroup } from "@angular/forms";


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tweetapp';
  isUserLoggedIn: boolean = false;
  loggedUsername: string;

  constructor(private service: MainService,private route:Router) {
 
    this.service.isUserLoggedIn.subscribe((res) => {
      this.isUserLoggedIn = res;
      if(localStorage.length > 0){
        let token = localStorage.getItem("token");
        this.isUserLoggedIn = token.includes(".");
        
      }
      if (this.isUserLoggedIn == true) {
        this.loggedUsername = localStorage.getItem("tweetapp-loggeduser");
      }
    });
  }

  ngOnIt(){
    this.service.validateToken(localStorage.getItem('token')).subscribe((res: any)=>{
      if(!res.valid){
        this.logOut();
      }
    })
  }

  logOut(){
    if(localStorage.length>0){
    localStorage.removeItem("tweetapp-loggeduser");
    localStorage.removeItem("token")
    }
    this.service.isUserLoggedIn.next(false);
    this.handle()
  }

  handle(){
    this.service.isUserLoggedIn.next(false);
  }

}
