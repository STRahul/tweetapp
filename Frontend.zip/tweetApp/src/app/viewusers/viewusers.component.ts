import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewusers',
  templateUrl: './viewusers.component.html',
  styleUrls: ['./viewusers.component.css']
})
export class ViewusersComponent implements OnInit {
  userNameList: any;
  userSelected: boolean = false;
  selectedUser: string;
  constructor(private service: MainService,private route: Router) {
    this.userNameList = [{}];
  }

  ngOnInit(): void {

    this.service.validateToken(localStorage.getItem('token')).subscribe((res: any)=>{
      if(!res.valid){
        this.logOut();
      }
      else{
        this.service.getAllUsers().subscribe((res) => {
          this.userNameList =res;
      });
      }
    })

   
  }

  logOut(){
    if(localStorage.length>0){
    localStorage.removeItem("tweetapp-loggeduser");
    localStorage.removeItem("token")
    }
    this.service.isUserLoggedIn.next(false);
    this.route.navigate(['/login'])
  }

  selectUser(user: string,e) {
    this.userSelected = true;
    this.selectedUser = user;
    e.scrollIntoView({behavior: 'smooth'});

  }

  closeUser(){
    this.userSelected = false;
  }

}
