import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MainService } from '../main.service';
import { TweetForm } from '../models/userInputForm';
import { IncomingResponse, TweetEntity } from '../models/incomingdata.model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-newtweet',
  templateUrl: './newtweet.component.html',
  styleUrls: ['./newtweet.component.css']
})
export class NewtweetComponent implements OnInit {
  tweeted = false;
  result = false;
  editTweet = false;
  currentTweet: TweetEntity;
  updated = false;

  tweetText: string;


  constructor(private service: MainService, private route: ActivatedRoute, private router: Router) {

  }

  ngOnInit(): void {
    this.service.validateToken(localStorage.getItem('token')).subscribe((res: any)=>{
      if(!res.valid)
        this.logOut();
    })
    let tweetId = this.route.snapshot?.params?.id != null ? this.route.snapshot.params.id : "";
    if (tweetId != null && this.service.selectedTweet != undefined && this.service.selectedTweet != null) {
      this.currentTweet = this.service.selectedTweet;
      this.editTweet = true;
      this.tweetText = this.currentTweet.tweetText;
    }
  }

  logOut(){
    if(localStorage.length>0){
    localStorage.removeItem("tweetapp-loggeduser");
    localStorage.removeItem("token")
    }
    this.service.isUserLoggedIn.next(false);
    this.router.navigate(['/login'])
  }

  updateTweet(message: string) {
    let myTweet = new TweetForm();
    myTweet.username = localStorage.getItem("tweetapp-loggeduser");
    myTweet.tweetText = message;

    this.service.updateTweet(myTweet, this.currentTweet.tweetId).subscribe((res: string) => {
    
        this.updated = true;
        this.result = true;
        this.tweetText = "";
        this.service.selectedTweet = null;
        this.editTweet = false;
        setTimeout(() => {
          this.router.navigate(['/tweets']);

        }, 1000)
      
    })

  }

  tweet(message: string) {
    let myTweet = new TweetForm();
    myTweet.username = localStorage.getItem("tweetapp-loggeduser");
    myTweet.tweetText = message;

    this.service.addTweetForUser(myTweet).subscribe((res: string) => {
      if (res == "Tweet created") {
        this.tweeted = true;
        this.result = true;
        this.tweetText = "";
      } else {
        this.tweeted = true;
        this.result = false;
      }
    });
  }


  resetData() {
    this.tweeted = false;
    this.result = false;
  }

}
