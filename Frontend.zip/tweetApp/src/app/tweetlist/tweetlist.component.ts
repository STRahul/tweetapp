import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { MainService } from '../main.service';
import { TweetEntity } from '../models/incomingdata.model';

@Component({
  selector: 'app-tweetlist',
  templateUrl: './tweetlist.component.html',
  styleUrls: ['./tweetlist.component.css']
})
export class TweetlistComponent implements OnInit {
  tweetsList: TweetEntity[];
  tweetSelected = false;
  tweet: TweetEntity;
  userNameTweets: string;

  constructor(private service: MainService, private route: ActivatedRoute,private currentRoute: Router) { }

  ngOnInit(): void {
    this.service.validateToken(localStorage.getItem('token')).subscribe((res: any)=>{
      if(!res.valid){
         this.logOut();
      }
      else{
        let username = this.route.snapshot?.params?.id != null ? this.route.snapshot.params.id : "";
        if(username!=""){
            console.log("tweet by user")
            this.service.getUserTweets(username).subscribe((res:any)=>{
              this.tweetsList = res;
            })
        }
        else{
          console.log("all tweet")
          this.service.getAllTweets().subscribe((res: any) => {
            this.tweetsList = res;
          });
        }
      }
    })
  }

  logOut(){
    if(localStorage.length>0){
    localStorage.removeItem("tweetapp-loggeduser");
    localStorage.removeItem("token")
    }
    this.service.isUserLoggedIn.next(false);
    this.currentRoute.navigate(['/login'])
  }

  viewTweet(idx,e) {
    
    this.tweet = this.tweetsList[idx];
    this.tweetSelected = true;
    e.scrollIntoView({behavior: 'smooth'});

  }

  closeTweet(){
    this.tweetSelected = false;
  }

  deleteTweet(idx) {
    let idsList = this.tweetsList.map((tweet) => tweet.tweetId);
    let currentIdx = idsList.indexOf(idx);
    this.tweetsList.splice(currentIdx, 1);
    this.tweetSelected = false;
    this.tweet = null;
  }

  likeTweet(tweet){
    this.tweetsList.map((item,index)=>{
        if(item.tweetId === tweet.tweetId){
          this.tweetsList[index].likes = tweet.likes;
        }
    });
  }

  replyTweet(tweet){
    this.tweetsList.map((item,index)=>{
        if(item.tweetId === tweet.tweetId){
          this.tweetsList[index].comments = tweet.comments;
        }
    });
  }


}
