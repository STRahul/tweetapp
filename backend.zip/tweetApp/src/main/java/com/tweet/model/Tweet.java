package com.tweet.model;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Size;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Data;

@Document(collection = "tweets")
@Data
@AllArgsConstructor
public class Tweet {

	@Id
    private String tweetId;
    private String username;
    @Size(max=144,message="tweet length must be less than or equal to 144 characters!!!")
    private String tweetText;
    private String tweetDate;
    private List<String> likes = new ArrayList<>();
    private List<Comment> comments = new ArrayList<>();

}