package com.tweet.model;

import lombok.Data;

@Data
public class TweetUpdate {
 
	String tweetText;
}
