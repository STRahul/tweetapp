package com.tweet.model;

import lombok.Data;

@Data
public class Reply {

	private String comment;
}
