package com.tweet.model;


import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Data
@Document(collection="users")

public class Users {


	@NotBlank(message="First Name cannot be blank!!!")
	private String firstName;
	
	@NotBlank(message="Last Name cannot be blank!!!")
	private String lastName;
	
	@Email(message ="Please provide valid email addess")
	@NotBlank(message="Email cannot be blank!!!")
	private String email;
	
	@Id
	@NotBlank(message="Username cannot be blank!!!")
	private String username;
	
	
	@NotBlank(message="Passsword cannot be blank!!!")
	private String password;
	
	private Long contactNumber;
	

	

	
	
}
