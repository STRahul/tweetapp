package com.tweet.model;

import lombok.Data;

@Data
public class LoginResponse {

	private String msg;
	private String token;
}
