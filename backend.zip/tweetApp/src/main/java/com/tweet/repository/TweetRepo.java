package com.tweet.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.tweet.model.Tweet;
@Repository
public interface TweetRepo extends MongoRepository<Tweet, String> {
	public List<Tweet> findByUsername(String username);
	
	
    @Query("{username : ?0, tweetId : ?1}")
    public Tweet findUserByUsernameAndTweetId(String username, String tweetId);
}
