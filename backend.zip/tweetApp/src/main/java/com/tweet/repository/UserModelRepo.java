package com.tweet.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tweet.model.UserModel;

@Repository
public interface UserModelRepo extends MongoRepository<UserModel,String> {
	public UserModel findByUsername(String username);
}
